create function "overlaps"(time without time zone, interval, time without time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
as
$$
select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$;

comment on function "overlaps"(time, interval, time, interval) is 'intervals overlap?';

alter function "overlaps"(time, interval, time, interval) owner to postgres;

